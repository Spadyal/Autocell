Unity3D-CoverFlow
=================

A simple CoverFlow example using LeanTween &amp; TouchScript
